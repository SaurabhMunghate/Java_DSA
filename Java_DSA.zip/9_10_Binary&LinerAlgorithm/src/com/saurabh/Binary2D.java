package com.saurabh;

public class Binary2D {
    

}
